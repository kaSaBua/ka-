package org.example.speedtest;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

public class speedtest {

        private static final String SSH_USER = "root";
        private static final String SSH_PASSWORD = "yhw1299275417.";
        private static final String SERVER_IP = "101.34.20.238";
        private static final int SSH_PORT = 22;
        private static final String LOCAL_IPERF_PATH = "C:\\Users\\jassi\\Downloads\\iperf-3.1.3-source.tar.gz";
    public static void main(String[] args) {

            // 安装iperf
            installIperf();

            // 测试iperf是否安装成功
            testIperf();

            // 卸载iperf
//            uninstallIperf();
        }

        private static void installIperf() {
            try {
                JSch jsch = new JSch();
                Session session = jsch.getSession(SSH_USER, SERVER_IP, SSH_PORT);
                session.setPassword(SSH_PASSWORD);
                session.setConfig("StrictHostKeyChecking", "no");
                session.connect();

                // 上传iperf安装包到远程服务器
                ChannelSftp channelSftp = (ChannelSftp) session.openChannel("sftp");
                channelSftp.connect();
                channelSftp.put(LOCAL_IPERF_PATH, "/tmp/tets/iperf-3.1.3-source.tar.gz");
                channelSftp.disconnect();

                 //解压并安装iperf
                String installCommand = "tar -xzf /tmp/tets/iperf.tar.gz -C /tmp/tets/ && cd /tmp/tets/iperf-* && ./configure && make && sudo make install";
                executeCommand(session, installCommand);

                session.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private static void testIperf() {
            try {
                JSch jsch = new JSch();
                Session session = jsch.getSession(SSH_USER, SERVER_IP, SSH_PORT);
                session.setPassword(SSH_PASSWORD);
                session.setConfig("StrictHostKeyChecking", "no");
                session.connect();

                String testCommand = "iperf3 --version";
                executeCommand(session, testCommand);

                session.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private static void uninstallIperf() {
            try {
                JSch jsch = new JSch();
                Session session = jsch.getSession(SSH_USER, SERVER_IP, SSH_PORT);
                session.setPassword(SSH_PASSWORD);
                session.setConfig("StrictHostKeyChecking", "no");
                session.connect();

                String uninstallCommand = "sudo apt-get remove -y iperf";
                executeCommand(session, uninstallCommand);

                session.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private static void executeCommand(Session session, String command) throws Exception {
            ChannelExec channel = (ChannelExec) session.openChannel("exec");
            channel.setCommand(command);

            channel.setInputStream(null);
            channel.setErrStream(System.err);

            channel.connect();
            channel.disconnect();
        }

}






