package org.example.speedtest;

import org.apache.sshd.client.SshClient;
import org.apache.sshd.client.session.ClientSession;
import org.apache.sshd.scp.client.ScpClient;
import org.apache.sshd.scp.client.ScpClientCreator;

public class SCP {
    //    private static String host = "192.168.67.48";
    private static String host = "101.34.20.238";
    //    private static String host = "192.168.71.29";
    private static String username = "root";
    private static String password = "Yhw1299275417.";
    private static Integer port = 22;

    //    private static String local = "F:\\miracle\\*";
    private static String local = "D:\\game\\ttt.txt";
    private static String remote = "/home/";
//    private static String remote = "F:\\luna\\";

    public static void scpFile(String local, String remote) throws Exception {
        long startTime = System.currentTimeMillis();

        // 创建 SSH客户端
        SshClient client = SshClient.setUpDefaultClient();
        // 启动 SSH客户端
        client.start();
        // 通过主机IP、端口和用户名，连接主机，获取Session
        ClientSession session = client.connect(username, host, port).verify().getSession();
        // 给Session添加密码
        session.addPasswordIdentity(password);
        // 校验用户名和密码的有效性
        boolean isSuccess = session.auth().verify().isSuccess();

        // 认证成功
        if (isSuccess) {
            long middleTime = System.currentTimeMillis();
            System.out.println("Connect host cost time: " + (middleTime - startTime) / 1000.0 + "s.");

            ScpClientCreator creator = ScpClientCreator.instance();
            // 创建 SCP 客户端
            ScpClient scpClient = creator.createScpClient(session);

            System.out.println("Scp beginning.");
            // ScpClient.Option.Recursive：递归copy，可以将子文件夹和子文件遍历copy
            scpClient.upload(local, remote, ScpClient.Option.Recursive);
            System.out.println("Scp finished.");

            // 释放 SCP客户端
            if (scpClient != null) {
                scpClient = null;
            }

            // 关闭 Session
            if (session != null && session.isOpen()) {
                session.close();
            }

            // 关闭 SSH客户端
            if (client != null && client.isOpen()&& !session.isOpen()) {
                client.stop();
                client.close();
            }
        }

        long endTime = System.currentTimeMillis();
        System.out.println("Total Cost time: " + (endTime - startTime) / 1000.0 + "s.");
    }

    public static void main(String[] args) throws Exception {
        scpFile(local, remote);
    }
}
