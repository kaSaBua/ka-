package org.example.speedtest;

import com.jcraft.jsch.*;

import java.io.IOException;

public class Test3 {
    public static void main(String[] args) throws IOException, JSchException, InterruptedException {
        String host1="101.34.20.238";
        String host2="207.60.173.88";
        String user="root";
        String password1="Yhw1299275417.";
        String password2="aWy8bT003Bnv";
        try{
        JSch jSch = new JSch();
        Session session1 = jSch.getSession(user, host1, 22);
        session1.setPassword(password1);
        session1.setConfig("StrictHostKeyChecking","no");
        session1.connect();

        Session session2 = jSch.getSession(user, host2, 22);
        session2.setPassword(password2);
        session2.setConfig("StrictHostKeyChecking","no");
        session2.connect();

        ChannelExec channel1 = (ChannelExec)session1.openChannel("exec");
        channel1.setCommand("dd if=/dev/zero bs =1000M count=1000 | ssh" +host2+"'cat > /dev/null'");
        channel1.connect();

        ChannelExec channel2 = (ChannelExec)session1.openChannel("exec");
        channel2.setCommand("dd if=/dev/zero bs =1000M count=1000 | ssh" +host1+"'cat > /dev/null'");
        channel1.connect();

        long startTime = System.currentTimeMillis();

        while (
                !channel1.isClosed() || !channel2.isClosed()
        ) {

            Thread.sleep(1000);
        }

        long endTime = System.currentTimeMillis();
        long duration = endTime - startTime;
        long speed = 2000000 / duration;
        System.out.println("Network speed between"+host1+"and"+host2+"is"+speed+"MB/s");
        channel1.disconnect();
        channel2.disconnect();
        session1.disconnect();
        session2.disconnect();

    }catch(Exception e){
        e.printStackTrace();
    }
}
}
