package org.example.speedtest;

import java.util.ArrayList;

public class ArrayListTest {
    public static void  main(String[] args){
        ArrayList<String> list = new ArrayList<>();
        boolean empty = list.isEmpty();
        System.out.println(empty);
        list.add("asa");
        boolean empty1 = list.isEmpty();
        System.out.println(empty1);

    }

}
