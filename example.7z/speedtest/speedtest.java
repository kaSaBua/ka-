package org.example.speedtest;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;

import java.io.*;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;

public class speedtest {

        private static final String SSH_USER = "root";
//        private static final String SSH_PASSWORD = "Yhw1299275417.";
//        private static final String SERVER_IP = "101.34.20.238";
private static final String SSH_PASSWORD = "ozpxEXRN4286";
private static final String SERVER_IP = "207.60.173.88";
        private static final int SSH_PORT = 22;
        private static final String LOCAL_IPERF_PATH = "C:\\Users\\jassi\\Downloads\\iperf-3.1.3-source.tar.gz";
    public static void main(String[] args) {

            // 安装iperf
            installIperf();

            // 测试iperf是否安装成功
            testIperf();

////             卸载iperf
//            uninstallIperf();
        }

        private static void installIperf() {
            try {
                JSch jsch = new JSch();
                Session session = jsch.getSession(SSH_USER, SERVER_IP, SSH_PORT);
                session.setPassword(SSH_PASSWORD);
                session.setConfig("StrictHostKeyChecking", "no");
                session.connect();
                ArrayList<Object> objects = new ArrayList<>();

                // 上传iperf安装包到远程服务器
                ChannelSftp channelSftp = (ChannelSftp) session.openChannel("sftp");
                channelSftp.connect();
                channelSftp.put(LOCAL_IPERF_PATH, "/tmp/test/iperf-3.1.3-source.tar.gz");
                channelSftp.disconnect();

                 //解压并安装iperf
                String installCommand = "tar zxf /tmp/test/iperf-3.1.3-source.tar.gz -C /tmp/test/ && cd /tmp/test/iperf-* && ./configure && make && sudo make install";
                executeCommand(session, installCommand);
                // 启动当服务器

                session.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private static void testIperf() {
            try {
                JSch jsch = new JSch();
                Session session = jsch.getSession(SSH_USER, SERVER_IP, SSH_PORT);
                session.setPassword(SSH_PASSWORD);
                session.setConfig("StrictHostKeyChecking", "no");
                session.connect();

                String testCommand = "iperf3 --version";
                executeCommand(session, testCommand);

                session.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private static void uninstallIperf() {
            try {
                JSch jsch = new JSch();
                Session session = jsch.getSession(SSH_USER, SERVER_IP, SSH_PORT);
                session.setPassword(SSH_PASSWORD);
                session.setConfig("StrictHostKeyChecking", "no");
                session.connect();

                String uninstallCommand = "make uninstall";
                executeCommand(session, uninstallCommand);

                session.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private static void executeCommand(Session session, String command) throws Exception {
            ChannelExec channel = (ChannelExec) session.openChannel("exec");
            channel.setCommand(command);

            channel.setInputStream(null);
            channel.setErrStream(System.err);

            channel.connect();
            channel.disconnect();
        }

}






