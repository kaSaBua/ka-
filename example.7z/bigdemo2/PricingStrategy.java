package org.example.bigdemo2;

// 定价策略接口
public interface PricingStrategy {
    double calculatePrice(double originalPrice);
}