package org.example.bigdemo2;

// 具体定价策略1
public class RegularPricingStrategy implements PricingStrategy {
    @Override
    public double calculatePrice(double originalPrice) {
        // 定价策略1
        return originalPrice;
    }
}
