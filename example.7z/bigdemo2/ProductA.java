package org.example.bigdemo2;

public class ProductA implements Product {
    private String name;
    private double price;

    public ProductA(String name, double price) {
        this.name = name;
        this.price = price;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public double calculateShippingCost() {
        // 运费计算策略1
        return price * 0.1;
    }
}


