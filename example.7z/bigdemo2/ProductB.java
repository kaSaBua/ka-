package org.example.bigdemo2;

// 具体商品类2
public class ProductB implements Product {
    private String name;
    private double price;

    public ProductB(String name, double price) {
        this.name = name;
        this.price = price;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public double calculateShippingCost() {
        // 运费计算策略2
        return price * 0.1;
    }
}
