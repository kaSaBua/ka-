package org.example.bigdemo2;

public class demo {
    public static void main(String[] args) {
        // 创建商品
        Product productA = ProductFactory.createProduct("ProductA", "商品A", 100.0);
        Product productB = ProductFactory.createProduct("ProductB", "商品B", 200.0);

        // 创建购物车
        ShoppingCart cart = new ShoppingCart();

        // 设置定价策略
        cart.setPricingStrategy(new DiscountPricingStrategy(0.5));

        // 加入商品到购物车
        cart.addProduct(productA);
        cart.addProduct(productB);

        // 结账
        cart.checkout();
    }
}
