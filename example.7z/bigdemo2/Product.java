package org.example.bigdemo2;

public interface Product {
    String getName();
    double getPrice();
    double calculateShippingCost();
}
