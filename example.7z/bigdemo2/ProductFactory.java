package org.example.bigdemo2;

// 商品工厂类
public class ProductFactory {
    public static Product createProduct(String type, String name, double price) {
        switch (type) {
            case "ProductA":
                return new ProductA(name, price);
            case "ProductB":
                return new ProductB(name, price);
            default:
                throw new IllegalArgumentException("未知商品类型");
        }
    }
}