package org.example.bigdemo2;

import java.util.ArrayList;
import java.util.List;

// 购物车类
public class ShoppingCart {
    private List<Product> products = new ArrayList<>();
    private PricingStrategy pricingStrategy;

    public void setPricingStrategy(PricingStrategy pricingStrategy) {
        this.pricingStrategy = pricingStrategy;
    }

    public void addProduct(Product product) {
        products.add(product);
    }

    public double calculateTotal() {
        double total = 0.0;
        for (Product product : products) {
            double price = product.getPrice();
            total += pricingStrategy.calculatePrice(price);
            total += product.calculateShippingCost();
        }
        return total;
    }

    public void checkout() {
        System.out.println("购物车商品:");
        for (Product product : products) {
            System.out.println(product.getName() + " - 价格: " + product.getPrice());
        }
        System.out.println("总价格: " + calculateTotal());
    }
}