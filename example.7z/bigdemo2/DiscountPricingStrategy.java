package org.example.bigdemo2;

// 具体定价策略2
public class DiscountPricingStrategy implements PricingStrategy {
    private double discountRate;

    public DiscountPricingStrategy(double discountRate) {
        this.discountRate = discountRate;
    }

    @Override
    public double calculatePrice(double originalPrice) {
        // 定价策略2
        return originalPrice * (1 - discountRate);
    }
}