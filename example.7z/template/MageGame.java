package org.example.template;

public class MageGame extends Game {
    @Override
    void initialize() {
        System.out.println("法师游戏初始化...");
    }

    @Override
    void startPlay() {
        System.out.println("法师开始游戏...");
    }

    @Override
    void endPlay() {
        System.out.println("法师游戏结束...");
    }
}