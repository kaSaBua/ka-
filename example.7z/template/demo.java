package org.example.template;

public class demo {
    public static void main(String[] args) {
        System.out.println("战士游戏:");
        Game warriorGame = new WarriorGame();
        warriorGame.play();

        System.out.println("\n法师游戏:");
        Game mageGame = new MageGame();
        mageGame.play();
    }
}
