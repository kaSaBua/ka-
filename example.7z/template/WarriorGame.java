package org.example.template;

public class WarriorGame extends Game{
    @Override
    void initialize() {
        System.out.println("战士游戏初始化...");
    }

    @Override
    void startPlay() {
        System.out.println("战士开始游戏...");
    }

    @Override
    void endPlay() {
        System.out.println("战士游戏结束...");
    }
}
