package org.example.flyweight;

public class CustomCharacter {
    private char character;

    public CustomCharacter(char character) {
        this.character = character;
    }

    public void display() {
        System.out.print(character);
    }
}
