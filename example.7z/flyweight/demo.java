package org.example.flyweight;

public class demo {
    public static void main(String[] args) {
        CharacterFactory factory = new CharacterFactory();

        // 创建并显示字符对象
        CustomCharacter a = factory.getCharacter('A');
        a.display();

        CustomCharacter b = factory.getCharacter('B');
        b.display();

        // 再次创建并显示相同的字符对象，实际上是共享已存在的对象
        CustomCharacter a2 = factory.getCharacter('A');
        a2.display();

        CustomCharacter space = factory.getCharacter(' ');
        space.display();
    }
}
