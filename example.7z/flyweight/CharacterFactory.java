package org.example.flyweight;

import java.util.HashMap;
import java.util.Map;

public class CharacterFactory {
    private Map<Character, CustomCharacter> characterMap = new HashMap<>();

    public CustomCharacter getCharacter(char character) {
        CustomCharacter existingCharacter = characterMap.get(character);

        if (existingCharacter == null) {
            existingCharacter = new CustomCharacter(character);
            characterMap.put(character, existingCharacter);
        }

        return existingCharacter;
    }
}
