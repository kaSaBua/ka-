package org.example.demo;

public class DiscountStrategy implements PricingStrategy {
    private double discountRate;

    public DiscountStrategy(double discountRate) {
        this.discountRate = discountRate;
    }

    @Override
    public double calculatePrice(double originalPrice) {
        return originalPrice * (1 - discountRate);
    }
}
