package org.example.demo;

public interface PricingStrategy {
    double calculatePrice(double originalPrice);
}
