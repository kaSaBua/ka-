package org.example.demo;

public class PriceCalculator {
    private PricingStrategy pricingStrategy;

    public void setPricingStrategy(PricingStrategy pricingStrategy) {
        this.pricingStrategy = pricingStrategy;
    }

    public double calculateFinalPrice(double originalPrice) {
        if (pricingStrategy == null) {
            throw new IllegalStateException("请设置价格策略");
        }
        return pricingStrategy.calculatePrice(originalPrice);
    }
}
