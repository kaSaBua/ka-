package org.example.demo;

public class demo1 {
    public static void main(String[] args) {
        // 创建上下文对象
        PriceCalculator calculator = new PriceCalculator();

        // 使用无折扣策略
        calculator.setPricingStrategy(new NoDiscountStrategy());
        double price1 = calculator.calculateFinalPrice(100.0);
        System.out.println("无折扣价格：" + price1);

        // 使用打折策略
        calculator.setPricingStrategy(new DiscountStrategy(0.2)); // 20% 折扣
        double price2 = calculator.calculateFinalPrice(100.0);
        System.out.println("打折价格：" + price2);
    }
}
