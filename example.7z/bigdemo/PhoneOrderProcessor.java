package org.example.bigdemo;

// 具体订单处理器2
public class PhoneOrderProcessor extends OrderProcessor {
    @Override
    protected void validateOrder(Order order) {
        System.out.println("验证电话订单...");
    }

    @Override
    protected void confirmOrder(Order order) {
        System.out.println("确认电话订单...");
    }

    @Override
    protected void shipOrder(Order order) {
        System.out.println("发货电话订单...");
    }

    @Override
    protected void completeOrder(Order order) {
        System.out.println("完成电话订单...");
    }
}
