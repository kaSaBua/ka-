package org.example.bigdemo;

/**
 * @author jassi
 */
public abstract  class OrderProcessor {
    public void process(Order order) {
        // 具体订单处理的通用流程
        validateOrder(order);
        confirmOrder(order);
        shipOrder(order);
        completeOrder(order);
    }

    protected abstract void validateOrder(Order order);

    protected abstract void confirmOrder(Order order);

    protected abstract void shipOrder(Order order);

    protected abstract void completeOrder(Order order);
}
