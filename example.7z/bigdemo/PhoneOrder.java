package org.example.bigdemo;

// 具体订单类2
public class PhoneOrder implements Order {
    @Override
    public void processOrder() {
        System.out.println("处理电话订单...");
    }
}
