package org.example.bigdemo;

public class OnlineOrderProcessor extends OrderProcessor {
    @Override
    protected void validateOrder(Order order) {
        System.out.println("验证在线订单...");
    }

    @Override
    protected void confirmOrder(Order order) {
        System.out.println("确认在线订单...");
    }

    @Override
    protected void shipOrder(Order order) {
        System.out.println("发货在线订单...");
    }

    @Override
    protected void completeOrder(Order order) {
        System.out.println("完成在线订单...");
    }
}

