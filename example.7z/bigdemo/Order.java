package org.example.bigdemo;

public interface Order {
    void processOrder();
}
