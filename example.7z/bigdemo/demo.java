package org.example.bigdemo;

public class demo {
    public static void main(String[] args) {
        // 创建订单
        Order onlineOrder = OrderFactory.createOrder("OnlineOrder");
        Order phoneOrder = OrderFactory.createOrder("PhoneOrder");

        // 创建订单处理器
        OrderProcessor onlineOrderProcessor = new OnlineOrderProcessor();
        OrderProcessor phoneOrderProcessor = new PhoneOrderProcessor();

        // 处理订单
        System.out.println("处理在线订单：");
        onlineOrderProcessor.process(onlineOrder);

        System.out.println("\n处理电话订单：");
        phoneOrderProcessor.process(phoneOrder);
    }
}
