package org.example.bigdemo;

public class OnlineOrder implements Order{
    @Override
    public void processOrder() {
        System.out.println("处理在线订单...");
    }
}

