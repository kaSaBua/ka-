package org.example.bigdemo;

public class OrderFactory {
    public static Order createOrder(String type) {
        switch (type) {
            case "OnlineOrder":
                return new OnlineOrder();
            case "PhoneOrder":
                return new PhoneOrder();
            default:
                throw new IllegalArgumentException("未知订单类型");
        }
    }
}
